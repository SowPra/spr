package com.demo.setup.demodatabase.sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

//import org.hibernate.annotations.common.util.impl.Log_.logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	public UserRepository userRepository;
	
/*	private List<UserBean> userBeans = new ArrayList<>(Arrays.asList(
			new UserBean("123", "Sowmya", "sow","sow.prabha"),
			new UserBean("java", "Core Java", "Core Java description.","2"),
			new UserBean("php", "Core PHP", "Core PHP description.","3")
			));*/
	

	public List<Members> getAllTopics() {
		// TODO Auto-generated method stub
		try {
			return (List<Members>) this.userRepository.findAll();	
		}
		catch(Exception e){
		
			List li = new ArrayList();
			li.add("Message");
			
			return li;
		}
		//return null;
	}


	public List<Members> getUser(String id) {
		// TODO Auto-generated method stub
		String ids =id;
		
		return userRepository.findByuserid(ids);
		
		//return (UserBean)userRepository.findById(id);
	}


	public void addUser(Members userBean) {
		// TODO Auto-generated method stub
		userBean.setId(UUID.randomUUID());
		userRepository.save(userBean);
		
	}


	public void updateUser(String id, Members userBean) {
		List<Members> mem =userRepository.findByuserid(id);
		if(userBean.getUserID().equals(mem.listIterator().next().getUserID())) {
		userBean.setId((mem.listIterator().next().getId()));
			userRepository.save(userBean);
		}
			
		
	}
	
	
	
	
	
}
