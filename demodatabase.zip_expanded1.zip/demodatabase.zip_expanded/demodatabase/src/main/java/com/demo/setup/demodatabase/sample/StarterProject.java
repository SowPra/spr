package com.demo.setup.demodatabase.sample;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StarterProject {
	
		@RequestMapping("/hello")
		public String Hello() {
			return "HI";
		}
		
		



}