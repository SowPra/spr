package com.demo.setup.demodatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemodatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodatabaseApplication.class, args);
		System.out.println("application started");
	}

}
