package com.demo.setup.demodatabase.sample;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;

@Entity
//@Table(name = "members", uniqueConstraints= @UniqueConstraint(columnNames={"id", "userid"}))
@Table(name = "members")
public class Members implements Serializable{
	
	@Id
	@Column(columnDefinition = "id")
	private UUID id;
	@Column(columnDefinition = "userid",unique=true)
	private String userid;
	@Column(columnDefinition = "username")
	private String username;
	@Column(columnDefinition = "password")
	private String password;
	@Column(columnDefinition = "email")
	private String email;
	//private String createdOn;
	//private String lastLogin;
	
	public Members() {
		
	}
	
	public Members(UUID id, String userID, String userName, String password, String email) {
		super();
		this.id = id;
		this.userid = userID;
		this.username = userName;
		this.password = password;
		this.email = email;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	/*public Members(String userID, String userName, String password, String email) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.password = password;
		this.email = email;
		//this.createdOn = createdOn;
		//this.lastLogin = lastLogin;
	}*/
	public String getUserID() {
		return userid;
	}
	public void setUserID(String userID) {
		this.userid = userID;
	}
	public String getUserName() {
		return username;
	}
	public void setUserName(String userName) {
		this.username = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	/*public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}*/


}
