package com.demo.setup.demodatabase.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sipios.springsearch.anotation.SearchSpec;


@RestController
public class UserController {
	
	@Autowired
	public UserService userService;
	
	// search query
	 private final UserRepository userRepository;

	    public UserController(UserRepository userRepository) {
	        this.userRepository = userRepository;
	    }
// search query
	@RequestMapping("/allUsers")
	public List<Members> getAllTopics() {
		//System.out.println("user bean called");
			return userService.getAllTopics();
		}
	@RequestMapping("/{id}")
	public List<Members> getUser(@PathVariable String id) {
		return userService.getUser(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/addUser")
	public String addUser(@RequestBody Members userBean) {
		
		userService.addUser(userBean);
		String response = "{\"success\": true, \"message\": Topic has been added successfully.}";
		return response;
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/updateUser/{id}")
		//@PutMapping("/topics/{id}")
		public String updateUser(@RequestBody Members userBean, @PathVariable String id) {
		 		
			userService.updateUser(id, userBean);
			String response = "{\"success\": true, \"message\": Topic has been updated successfully.}";
			return response;
	}
	// search query
	@RequestMapping(method=RequestMethod.GET, value="/find")
	//public List<Members> searchQuery()
    public ResponseEntity<List<Members>> searchForCars(@SearchSpec Specification<Members> specs) {
        return new ResponseEntity<>(userRepository.findAll(Specification.where(specs)), HttpStatus.OK);
    }
	// search query
}

