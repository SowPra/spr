package com.demo.setup.demodatabase.sample;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource

@Repository
//@Transactional
public interface UserRepository extends CrudRepository<Members, UUID>, JpaRepository<Members, UUID>,JpaSpecificationExecutor<Members>{

	public List<Members> findByuserid(String userID); 
	
	// search operation -- added JPA specificationExecutor
	//@Query("select * from Members m where m.userid=?1");
}